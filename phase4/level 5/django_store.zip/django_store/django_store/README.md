A Book Store App written in python and django
